package com.example.alarmmanagerintegration

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class AlarmActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set the content view
        setContentView(R.layout.activity_alarm)

        // Get the message from the intent
        val message = intent.getStringExtra("ALARM_MESSAGE") ?: "Alarm!"

        // Set the message to the TextView
        val messageTextView: TextView = findViewById(R.id.alarmMessageTextView)
        messageTextView.text = message

        // Set up the dismiss button
        val dismissButton: Button = findViewById(R.id.dismissButton)
        dismissButton.setOnClickListener {
            finish()
        }

        // Turn on the screen and show the activity over the lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
    }
}
