package com.example.alarmmanagerintegration

import android.app.IntentService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.util.Log
import androidx.core.app.NotificationCompat

class AlarmService : IntentService("AlarmService") {

    companion object {
        private const val TAG = "AlarmService"
        private const val CHANNEL_ID = "ALARM_SERVICE_CHANNEL"
    }

    override fun onCreate() {
        super.onCreate()

        // Create Notification Channel for devices with Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alarm Service",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onHandleIntent(intent: Intent?) {
        Log.d(TAG, "Service started. Alarm triggered!")

        // Create a foreground notification
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Alarm Triggered")
            .setContentText("The alarm has been triggered and is running in the background.")
            .setSmallIcon(R.drawable.ic_launcher_foreground) // Make sure you have this icon in your resources
            .build()

        // Start the service in the foreground
        startForeground(1, notification)

        // Here, you can put the logic to open your HomeScreen activity
        val homeIntent = Intent(this, HomeScreen::class.java)
        homeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(homeIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service destroyed.")
    }
}
